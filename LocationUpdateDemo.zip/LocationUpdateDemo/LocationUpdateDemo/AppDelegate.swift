//
//  AppDelegate.swift
//  LocationUpdateDemo
//
//  Created by ranjit singh on 12/13/16.
//  Copyright © 2016 ranjit singh. All rights reserved.
//

import UIKit
import CoreLocation

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, CLLocationManagerDelegate {


    var window: UIWindow?
    //var locationManager = CLLocationManager()
    lazy var locationManager: CLLocationManager! = {
        let manager = CLLocationManager()
        manager.allowsBackgroundLocationUpdates = true
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.pausesLocationUpdatesAutomatically = false
        manager.delegate = self
        manager.requestAlwaysAuthorization()
        
        return manager
    }()
    var lastNotifictionDate = NSDate()
   


    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch.
        let settings = UIUserNotificationSettings(forTypes: [.Alert], categories: nil)
        UIApplication.sharedApplication().registerUserNotificationSettings(settings)
        locationManager.startUpdatingLocation()
        return true
    }

   func locationManager(manager: CLLocationManager!, didUpdateToLocation newLocation: CLLocation!, fromLocation oldLocation: CLLocation!) {
        // Do something interesting.
        var bgTask = UIBackgroundTaskIdentifier()
        bgTask = UIApplication.sharedApplication().beginBackgroundTaskWithExpirationHandler { () -> Void in
            UIApplication.sharedApplication().endBackgroundTask(bgTask)
        }
        
        print(newLocation.coordinate.latitude)
        
        
        if (bgTask != UIBackgroundTaskInvalid)
        {
            UIApplication.sharedApplication().endBackgroundTask(bgTask);
            bgTask = UIBackgroundTaskInvalid;
        }

        // I make this function return immediately until 10sec passed after previous notification.
        let now = NSDate()
        if lastNotifictionDate.dateByAddingTimeInterval(20).compare(now) == .OrderedDescending {
            //NSLog("Not yet")
            return
        }
        //NSLog("It's time")
        lastNotifictionDate = now
        
        // Fire local notification, without sound configured for simplicity.
        let notification = UILocalNotification()
        notification.alertBody = "latitude longitude:\(newLocation.coordinate.latitude)"
        UIApplication.sharedApplication().presentLocalNotificationNow(notification)
    }

    
    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
        
        self.locationManager.delegate = self
        self.locationManager.startUpdatingLocation() // I know i should be using signification location option here. this is just for testing now.
    }
    
//    func locationManager(manager: CLLocationManager!, didUpdateToLocation newLocation: CLLocation!, fromLocation oldLocation: CLLocation!) {
//        self.sendBackgroundLocationToServer(newLocation);
//    }
////    
//    func sendBackgroundLocationToServer(location: CLLocation) {
//        var bgTask = UIBackgroundTaskIdentifier()
//        bgTask = UIApplication.sharedApplication().beginBackgroundTaskWithExpirationHandler { () -> Void in
//            UIApplication.sharedApplication().endBackgroundTask(bgTask)
//        }
//        
//        print(location.coordinate.latitude)
//        
//        if (bgTask != UIBackgroundTaskInvalid)
//        {
//            UIApplication.sharedApplication().endBackgroundTask(bgTask);
//            bgTask = UIBackgroundTaskInvalid;
//        }
//    }
//    
    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
        application.beginBackgroundTaskWithExpirationHandler{}
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        application.beginBackgroundTaskWithExpirationHandler{}
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        application.beginBackgroundTaskWithExpirationHandler{}
    }
}

